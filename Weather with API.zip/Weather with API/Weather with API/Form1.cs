﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using System.Net;

namespace Weather_with_API
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string APIkey = "55a35fc4ce6ea550de139148cc5f9998";
      

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void SearchCity_Click(object sender, EventArgs e)
        {
            getWeather();
        }
        void getWeather()
        {
            try
            {
                using (WebClient web = new WebClient())
                {
                    string url = string.Format("https://api.openweathermap.org/data/2.5/weather?q={0}&appid={1}", tblCity.Text, APIkey);
                    var json = web.DownloadString(url);
                    WeatherInpo1.root Info = JsonConvert.DeserializeObject<WeatherInpo1.root>(json);

                    picIcon.ImageLocation = "https://openweathermap.org/img/w/" + Info.weather[0].icon + ".png";
                    labCondition.Text = Info.weather[0].main;
                    labDetail.Text = Info.weather[0].description;
                    labSunrise.Text = convertDateTime(Info.sys.sunrise).ToShortTimeString();
                    labSunset.Text = convertDateTime(Info.sys.sunset).ToShortTimeString();

                    labWind.Text = Info.wind.speed.ToString();
                    labPressure.Text = Info.main.pressure.ToString();
                }
            }
            catch { }
           

            DateTime convertDateTime(long millisec)
            {
                DateTime day = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc).ToLocalTime();
                day = day.AddSeconds(millisec).ToLocalTime();

                return day;

            }


        }

           
        
    }
}